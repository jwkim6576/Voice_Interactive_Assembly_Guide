^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package dsr_bringup2
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
2.0.1 (2021-07-01)
------------------
* update ROS2 Humble
* change name from dsr_launcher2 to dsr_bringup2

1.1.0 (2021-07-01)
------------------
* update changelog
* modify launch file
* launch drcf-emulator automatically
* update moveit package
* ROS2 Alpha
* for newest ros2_control package
* ROS2 Alpha
* ROS2 Alpha
* Update package.xml
* ROS2 Alpha
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics

* modify launch file
* launch drcf-emulator automatically
* update moveit package
* ROS2 Alpha
* for newest ros2_control package
* ROS2 Alpha
* ROS2 Alpha
* Update package.xml
* ROS2 Alpha
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics

* ROS2 Alpha
* Update package.xml
* ROS2 Alpha
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics

0.1.1 (2020-10-29)
------------------
* Update package.xml
* ROS2 Alpha
* Contributors: doosan robotics ros master, doosan-robotics
